#include <iostream>
#include <cstdio>
using namespace std;

int main(int argc,char**argv){
  int c[128];
  int aaa;
  c[0]=aaa;
  printf("aaa = %d\n",aaa);
  return 0;
}

