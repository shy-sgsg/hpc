#ifndef MATRIX_H
#define MATRIX_H

void SimpleMultiply(const double* a, const double* b, double* c,const size_t M, const size_t N, const size_t K) ;

#endif
